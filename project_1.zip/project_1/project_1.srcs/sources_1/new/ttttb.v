`timescale 1ns / 1ps

module tb_tic_tac_toe();

    // Signals
    reg clk;
    reg reset;
    reg left, right, confirm;
    wire [8:0] leds;
    wire lreset;
    wire game_over;
    wire p1, p2;
    wire player_turn;
    wire [1:0] winner;
    wire [1:0] p_row;
    wire [1:0] p_col;

    // Instantiate the tic_tac_toe module
    tic_tac_toe dut (
        .clk(clk),
        .reset(reset),
        .left(left),
        .right(right),
        .confirm(confirm),
        .leds(leds),
        .lreset(lreset),
        .game_over(game_over),
        .p1(p1),
        .p2(p2),
        .player_turn(player_turn),
        .winner(winner),
        .p_row(p_row),
        .p_col(p_col)
    );

    // Clock generation
    always begin
        clk = 0;
        #5;
        clk = 1;
        #5;
    end

    // Reset initialization
    initial begin
        reset = 1;
        #10;
        reset = 0;
        left = 0;
        right = 0;
        confirm = 0;
        #10;
        left = 1;
        #10;
        left = 0;
        #3;
        reset = 1;
        #27;

        #3;
        confirm = 1; #3; confirm = 0; #17;
        // Move to position (0, 0) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (0, 1) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (0, 2) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1, 0) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1, 1) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1, 2) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 0) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 1) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 2) and confirm
        // End simulation after sufficient time
        #30;
        
        /////////////////////////////////////////////////
        reset = 0;
        #3;
        reset = 1;
        #27;
        confirm = 1; #3; confirm = 0; #17;
        // Move to position (0, 0) and confirm of player 1
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (0, 1) and confirm of player 2
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1,0) and confirm of player 1
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1, 1) and confirm of player 2
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 2) and confirm of player 1
        left = 1; #3; left = 0; #7;
        confirm = 1; #3; confirm = 0; #17;
        // Move to position (2, 1) and confirm of player 2
        
        #30;
        /////////////////////////////////////////////////
        
        reset = 0;
        #3;
        reset = 1;
        #27;
        confirm = 1; #3; confirm = 0; #17;
        // Move to position (0, 0) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (0, 1) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (0, 2) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1, 0) and confirm
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (1, 1) and confirm
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        right = 1; #3; right = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 2) and confirm of p2
        left = 1; #3; left = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 1) and confirm of p1
        left = 1; #3; left = 0; #7;
        confirm = 1; #3; confirm = 0; #17;

        // Move to position (2, 0) and confirm of p2
        left = 1; #3; left = 0; #7;
        confirm = 1; #3; confirm = 0; #17;
        
        // Move to position (1, 2) and confirm of p1
        // End simulation after sufficient time
        #30;
        
        #20;
        $finish; // Finish simulation
    end

endmodule