`timescale 1ns / 1ps

module tic_tac_toe (
    input wire clk,         
    input wire reset,       // Reset active low
    input wire left,      
    input wire right,     
    input wire confirm,   
    output reg [8:0] leds, 
    output reg lreset,      
    output reg game_over,       
    output reg p1,    
    output reg p2,   
    output reg player_turn,                
    output reg [1:0] winner,       
    output reg [1:0] p_row,          
    output reg [1:0] p_col           
);

parameter SIZE = 3;
parameter X = 1'b0;
parameter O = 1'b1;
parameter EMPTY = 2'b00;
parameter X_MARK = 2'b01;
parameter O_MARK = 2'b10;
parameter IDLE = 1'b0;
parameter PLACE = 1'b1;

reg [1:0] board [2:0][2:0];
reg state;
integer i, j;

always @(posedge clk or negedge reset) begin
    if (~reset) begin
        // Reset Game
        lreset <= 1;
        state <= IDLE;
        player_turn <= X;
        for (i = 0; i < SIZE; i = i + 1) begin
            for (j = 0; j < SIZE; j = j + 1) begin
                board[i][j] <= EMPTY;
            end
        end
        p_row <= 2'b00;
        p_col <= 2'b00;
        p1 <= 1'b0;
        p2 <= 1'b0; 
        game_over <= 1'b0;
        winner <= 2'b00;
        leds <= 9'b000000000;
    end 
    else begin
        lreset <= 0;
        
        // Logic Game
        if (game_over == 0) begin
            if (state == IDLE) begin
                // Move cursor (P)
                if (left) begin
                    if (p_col > 0) p_col <= p_col - 1;
                    else begin
                        p_col <= SIZE - 1;
                        p_row <= (p_row == 0) ? SIZE - 1 : p_row - 1;
                    end
                end
                else if (right) begin
                    if (p_col < SIZE - 1) p_col <= p_col + 1;
                    else begin
                        p_col <= 0;
                        p_row <= (p_row == SIZE - 1) ? 0 : p_row + 1;
                    end
                end
                
                // Confirm
                if (confirm && board[p_row][p_col] == EMPTY) begin
                    board[p_row][p_col] <= (player_turn == X) ? X_MARK : O_MARK;
                    state <= PLACE;
                end
            end
            else if (state == PLACE) begin
                // Check Win/Lose
                if ((board[p_row][0] == board[p_row][1] && board[p_row][1] == board[p_row][2] && board[p_row][0] != EMPTY) ||
                    (board[0][p_col] == board[1][p_col] && board[1][p_col] == board[2][p_col] && board[0][p_col] != EMPTY) ||
                    (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[1][1] != EMPTY) ||
                    (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[1][1] != EMPTY)) 
                begin
                    game_over <= 1;
                    winner <= (player_turn == X) ? 2'b01 : 2'b10;
                    p1 <= (player_turn == X);
                    p2 <= (player_turn == O);
                end
                // Check Draw
                else if (board[0][0]!=EMPTY && board[0][1]!=EMPTY && board[0][2]!=EMPTY &&
                         board[1][0]!=EMPTY && board[1][1]!=EMPTY && board[1][2]!=EMPTY &&
                         board[2][0]!=EMPTY && board[2][1]!=EMPTY && board[2][2]!=EMPTY) 
                begin
                    game_over <= 1;
                    winner <= 2'b11;
                    p1 <= 1; p2 <= 1;
                end
                
                // Switch turn
                if (game_over == 0) begin
                    player_turn <= ~player_turn;
                end
                state <= IDLE;
            end
        end

        // Update LED
        if (game_over) begin
            case (winner)
                2'b01: leds <= 9'b101_010_101; // X Win
                2'b10: leds <= 9'b111_101_111; // O Win
                default: leds <= 9'b111_111_111; // Draw
            endcase
        end else begin
            leds <= 9'b000000000;
            leds[p_row * 3 + p_col] <= 1'b1; // Cursor (P) position
        end
    end
end

endmodule
